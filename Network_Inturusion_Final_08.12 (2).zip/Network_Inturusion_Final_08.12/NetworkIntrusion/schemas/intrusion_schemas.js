var mongoose = require('mongoose');

// Anomaly result
var resultSchema  = new mongoose.Schema({
  Flow_ID : {type : String},
  prediction : {type : String},
  Date : {type : String},
  Day_Night : {type : String}
});

// exports multiple schemas
exports.intrusion_schema = mongoose.model('Network_intrusion', resultSchema,'Network_intrusion');