# importing required libraries
import numpy as np
import pandas as pd

import matplotlib.pyplot as plt

from sklearn.preprocessing import MinMaxScaler
# from sklearn.preprocessing import StandardScaler
# from sklearn.preprocessing import LabelEncoder

from sklearn.model_selection import train_test_split 

import xgboost as xgb

from sklearn.metrics import f1_score

import time
import datetime

from pymongo import MongoClient

from sklearn.preprocessing import LabelEncoder


mongo_client = MongoClient('mongodb://rspirit:rspirit@54.180.125.129/anomaly_test?authSource=admin&readPreference=primary&authMechanism=SCRAM-SHA-1')

data = pd.read_csv('dataset_original.csv')

data['Sub_Cat'].value_counts()
sub_cat_label = ['Mirai-UDP Flooding', 'Mirai-Hostbruteforceg', 'DoS-Synflooding ',
                 'Mirai-HTTP Flooding ', 'Mirai-Ackflooding','Scan Port OS','Normal', 
                 'MITM ARP Spoofing', 'Scan Hostport']

#ip와 Timestamp는 학습에 영향이 없으므로 제거
new_data = data.drop(columns=['Flow_ID', 'Src_IP', 'Dst_IP', 'Timestamp'])

num_col = data.select_dtypes(include='number').columns

check_num_col = new_data.drop(columns=num_col)

# using minmax scaler for normalizing data
minmax_scale = MinMaxScaler(feature_range=(0, 1))
def normalization(df,col):
  for i in col:
    arr = df[i]
    arr = np.array(arr)
    df[i] = minmax_scale.fit_transform(arr.reshape(len(arr),1))
  return df

#infinity값 삭제
new_data_drop = new_data.replace([np.inf, -np.inf], np.nan)

sub_cat_data = new_data.drop(columns= ['Label', 'Cat'])

num_col = sub_cat_data.select_dtypes(include='number').columns

sub_cat_data = sub_cat_data.replace([np.inf, -np.inf], np.nan)
sub_cat_data = sub_cat_data.dropna()
sub_cat_data = normalization(sub_cat_data, num_col)


X = sub_cat_data.iloc[:, :-1]
y = sub_cat_data.iloc[:, -1:]


le = LabelEncoder()
result = le.fit_transform(y['Sub_Cat'])
y = result

X_train, X_test, y_train, y_test= train_test_split(X, y, test_size=0.3, random_state=777)

coarse_hyperparameters_list = pd.read_csv('xgb_param(f1_score)0622.csv')

xgb_classfier = xgb.XGBClassifier(
    objective= 'multi:softprob',
    num_class= 9,
    n_estimators = int(coarse_hyperparameters_list.iloc[:1,:].values[0][1]),
    learning_rate = coarse_hyperparameters_list.iloc[:1,:].values[0][2],
    max_depth= int(coarse_hyperparameters_list.iloc[:1,:].values[0][3]),
    max_bin = int(coarse_hyperparameters_list.iloc[:1,:].values[0][4]),
    subsample = coarse_hyperparameters_list.iloc[:1,:].values[0][5],
    colsample_bytree = coarse_hyperparameters_list.iloc[:1,:].values[0][6],
    gamma = coarse_hyperparameters_list.iloc[:1,:].values[0][7],
    reg_lambda = coarse_hyperparameters_list.iloc[:1,:].values[0][8],
    reg_alpha = coarse_hyperparameters_list.iloc[:1,:].values[0][9],
    random_state=777,)

xgb_classfier.fit(X_train, y_train)

prediction = xgb_classfier.predict(X_test)

prediction = le.inverse_transform(prediction)

DB = mongo_client['Network_intrusion']

collection = DB['Network_intrusion']

result = pd.DataFrame()

result['prediction'] = prediction

result_drop = data.replace([np.inf, -np.inf], np.nan)
sub_cat_result = result_drop.drop(columns= ['Label', 'Cat'])
sub_cat_result = sub_cat_result.dropna()

X = sub_cat_result.iloc[:, :-1]
y = sub_cat_result.iloc[:, -1:]

X_train, X_test, y_train, y_test= train_test_split(X, y, test_size=0.3, random_state=777)

new_result = X_test[['Flow_ID', 'Timestamp']]

new_result = new_result.reset_index()

new_result['prediction'] = result['prediction']

new_result.drop(columns=['index'], inplace= True)

time_split = new_result['Timestamp'].str.split('/').str[2]

Date = time_split.str.split(' ').str[0]+new_result['Timestamp'].str.split('/').str[1]+new_result['Timestamp'].str.split('/').str[0]

Time = time_split.str.split(' ').str[1].str.split(':').str[0]+time_split.str.split(' ').str[1].str.split(':').str[1] 

new_time = Date + Time

new_result['Date'] = new_time

new_result['Day_Night'] = time_split.str.split(' ').str[2].str.split(':').str[0] 

new_result.drop(columns=['Timestamp'], inplace= True)

collection.insert_many(new_result.to_dict('records'))