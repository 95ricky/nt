const Influx = require('influx')

const express = require('express')
const http = require('http')
const os = require('os')

const app = express()

const influx = new Influx.InfluxDB({
    host: 'localhost',
    database: 'network_intrusion',
    schema: [
      {
        measurement: 'network_intrusion',
        fields: {
          'Flow_ID' : Influx.FieldType.STRING,
          'prediction' : Influx.FieldType.STRING,
          'Date' : Influx.FieldType.STRING,
        },
        tags: [
          'host'
        ]
      }
    ]
})

influx.getDatabaseNames()
.then(names => {
if (!names.includes('network_intrusion')) {
    return influx.createDatabase('network_intrusion');
}
})
.then(() => {
http.createServer(app).listen(2500, function () {
    console.log('Listening on port 2500')
})
})
.catch(err => {
console.error(`Error creating Influx database!`);
})

app.get("/all/result", function (req, res) {
    console.log('all')
    influx
      .query(
        `
      select * from network_intrusion
    `
      )
      .then((result) => {
       	res.status(200).json(result);
      })
      .catch((err) => {
        res.status(500).send(err.stack);
      });
  });

app.get("/attack/normal", function (req, res) {
  influx
    .query(
      `
    select * from network_intrusion where prediction = 'Normal'
  `
    )
    .then((result) => {
          console.log(result)
      res.json(result);
    })
    .catch((err) => {
      res.status(500).send(err.stack);
    });
});
// normal ########################################################
app.get("/attack/normal", function (req, res) {
  influx
    .query(
      `
    select * from network_intrusion where prediction = 'Normal'
  `
    )
    .then((result) => {
          console.log(result)
      res.json(result);
    })
    .catch((err) => {
      res.status(500).send(err.stack);
    });
});


// DoS-Synflooding ########################################################
app.get("/attack/dos_syn", function (req, res) {
  influx
    .query(
      `
    select * from network_intrusion where prediction = 'DoS-Synflooding'
  `
    )
    .then((result) => {
          console.log(result)
      res.json(result);
    })
    .catch((err) => {
      res.status(500).send(err.stack);
    });
});


// MITM ARP Spoofing ########################################################
app.get("/attack/mitm", function (req, res) {
  influx
    .query(
      `
    select * from network_intrusion where prediction = 'MITM ARP Spoofing'
  `
    )
    .then((result) => {
          console.log(result)
      res.json(result);
    })
    .catch((err) => {
      res.status(500).send(err.stack);
    });
});


// Mirai-Ackflooding ########################################################
app.get("/attack/mirai_ack", function (req, res) {
  influx
    .query(
      `
    select * from network_intrusion where prediction = 'Mirai-Ackflooding'
  `
    )
    .then((result) => {
          console.log(result)
      res.json(result);
    })
    .catch((err) => {
      res.status(500).send(err.stack);
    });
});


// Mirai-HTTP Flooding ########################################################
app.get("/attack/mirai_http", function (req, res) {
  influx
    .query(
      `
    select * from network_intrusion where prediction = 'Mirai-HTTP Flooding'
  `
    )
    .then((result) => {
          console.log(result)
      res.json(result);
    })
    .catch((err) => {
      res.status(500).send(err.stack);
    });
});


// Mirai-Hostbruteforceg ########################################################
app.get("/attack/mirai_host", function (req, res) {
  influx
    .query(
      `
    select * from network_intrusion where prediction = 'Mirai-Hostbruteforceg'
  `
    )
    .then((result) => {
          console.log(result)
      res.json(result);
    })
    .catch((err) => {
      res.status(500).send(err.stack);
    });
});


// Mirai-UDP Flooding ########################################################
app.get("/attack/mirai_udp", function (req, res) {
  influx
    .query(
      `
    select * from network_intrusion where prediction = 'Mirai-UDP Flooding'
  `
    )
    .then((result) => {
          console.log(result)
      res.json(result);
    })
    .catch((err) => {
      res.status(500).send(err.stack);
    });
});


// Scan Hostport ########################################################
app.get("/attack/scan_host", function (req, res) {
  influx
    .query(
      `
    select * from network_intrusion where prediction = 'Scan Hostport'
  `
    )
    .then((result) => {
          console.log(result)
      res.json(result);
    })
    .catch((err) => {
      res.status(500).send(err.stack);
    });
});


// Scan Port OS ########################################################
app.get("/attack/scan_port", function (req, res) {
  influx
    .query(
      `
    select * from network_intrusion where prediction = 'Scan Port OS'
  `
    )
    .then((result) => {
          console.log(result)
      res.json(result);
    })
    .catch((err) => {
      res.status(500).send(err.stack);
    });
});

module.exports=Influx