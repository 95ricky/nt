import datetime
import random
import time
import os
import csv
from csv import reader
import argparse
from influxdb import client as influxdb

host = 'localhost'
port = 8086
user = 'root'
password = 'root'
db = 'network_intrusion'

db = influxdb.InfluxDBClient(host, 8086, user, password, db)
def read_data():
    with open('result.csv') as f:
        return [x.split(',') for x in f.readlines()[1:]]

a = read_data()

for metric in a:
    influx_metric = [{
        'measurement': 'network_intrusion',
        'time': metric[0],
        'fields': {
            'Flow_ID': metric[1],
            'prediction' : metric[2],
            'Date' : metric[3]
        }
    }]
    db.write_points(influx_metric)