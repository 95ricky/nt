const mongoose = require('mongoose');
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const path = require('path');
app.use(express.static('public'));


/*
  body-parser
  : 요청의 본문을 해석해주는 미들웨어이다.
    보통 폼 데이터나 AJAX요청의 데이터를 처리한다
*/
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());

/*
  그런데 이전에 express미들웨어에서의 app.js에서는 body-parser를 사용하지 않았다.
  익스프레스 4.16.0버전 부터 body-parser의 일부 기능이 익스프레스에 내장되었기 때문이다.
*/
app.use(express.urlencoded({ extended: true }))   ;
app.use(express.json());

/*
  Raw는 본문이 버퍼 데이터일 때, Text는 본문이 텍스트 데이터일 때  해석하는 미들웨어이다.
  서비스에 적용하고 싶다면 body-parser를 설치한 후 다음과 같이 추가한다.
*/
app.use(bodyParser.text());

const PORT = 2500;
const MONGO_URI = 'mongodb://rspirit:rspirit@54.180.125.129/Network_intrusion?authSource=admin&readPreference=primary&authMechanism=SCRAM-SHA-1';

app.use(express.static('public'));


// CONNECT to MongoDB
const db = mongoose
    .connect(MONGO_URI,{useNewUrlParser: true, useUnifiedTopology: true})
    .then(() => console.log("Connected to MongoDB"))
    .catch((e) => console.error(e));

// ROUTERS
app.use('/', require('./routes/intrusion_api'));

// static router을 통하여 효율적으로 서브
app.use('/static', express.static('./static/js/'));
app.use('/css', express.static('./static/css/'))

app.listen(PORT, () => console.log(`Server lisetening on port ${PORT}`));


