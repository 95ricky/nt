const router = require('express').Router();
const { Router } = require('express');
const Base = require('../schemas/intrusion_schemas'); 

var intrusion_schema = Base.intrusion_schema;

const mongoose = require('mongoose');

router.get('/', function(req, res){
    res.status(200).send('routes connection succeed!!');
});

router.get('/all/result/', function(req, res){
    intrusion_schema.find()
    .select('-_id')
      .then((datas) => {
        console.log(datas.length);
        if (!datas.length) return res.status(404).send({ err: 'Data not found' });
        res.status(200).json(datas);
      })
      .catch(e => res.status(500).send(e));
  });


router.get('/result/date', function (req, res) {
    var from_date = (req.query.from_date);
    var to_date = (req.query.to_date);
    intrusion_schema.find().where('Date').gte(from_date).lte(to_date).select('-_id').then((datas) => {
        if (!datas.length) return res.status(404).send({ err: 'Data not found' });
        console.log(`데이터 개수: ${datas.length}`); // 템플릿 문자열
	res.status(200).json(datas);
    })
    .catch(e => res.status(500).send(e));
});

router.get('/result/attack', function (req, res) {
    var attack = (req.query.attack);
    intrusion_schema.find()
      .where('prediction').eq(attack)
      .select('-_id')
      .then((datas) => {
        if (!datas.length) return res.status(404).send({ err: 'Data not found' });
        console.log(`데이터 개수: ${datas.length}`); // 템플릿 문자열
	res.status(200).json(datas);
      })
      .catch(e => res.status(500).send(e));
  });

module.exports = router